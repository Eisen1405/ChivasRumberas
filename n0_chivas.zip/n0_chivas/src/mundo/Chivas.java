package mundo;

public class Chivas {

	private String nombreChiva;
	private int capacidad;
	private int pasajerosPermitidos;
	private int cantidadSillas;
	private double precioHora;
	private double horasAlquiladas;
		
	public double calcularAlquilerChiva( )
	{
		return precioHora * horasAlquiladas;
	}
		
	public double calcularDineroRecaudado()
	{
		return calcularAlquilerChiva( );
	}
	
	public Chivas(String pNombreChiva, int pCapacidad, int pPasajerosPermitidos, 
				int pCantidadSillas, double pPrecioHora, double pHorasAlquiladas)
	{
		nombreChiva = pNombreChiva;
		capacidad = pCapacidad;
		pasajerosPermitidos = pPasajerosPermitidos;
		cantidadSillas = pCantidadSillas;
		precioHora = pPrecioHora;
		horasAlquiladas = pHorasAlquiladas;
	}
	public String getNombreChiva( )
	{
		return nombreChiva;
	}
	public int getCapacidad( )
	{
		return capacidad;
	}
	
	public int getPasajerosPermitidos( )
	{
		return pasajerosPermitidos;
	}
	
	public int getCantidadSillas( )
	{
		return cantidadSillas;
	}
	
	public double getPrecioHora( )
	{
		return precioHora;
	}
	
	public double getHorasAlquiladas( )
	{
		return horasAlquiladas;
	}
	
	
	public void setNombreChiva(String pNombreChiva )
	{
		nombreChiva = pNombreChiva;
	}
	public void setCapacidad ( int pCapacidad )
	{
		capacidad= pCapacidad;
	}
	public void setPasajerosPermitidos(int pPasajerosPermitidos)
	{
		pasajerosPermitidos = pPasajerosPermitidos;
	}
	public void setCantidadSillas(int pCantidadSillas )
	{
		cantidadSillas = pCantidadSillas;
	}
	public void setPrecioHora (double pPrecioHora)
	{
		precioHora = pPrecioHora;
	}
	public void setHorasAlquiladas (double pHorasAlquiladas)
	{
		horasAlquiladas = pHorasAlquiladas;
	}
	
}


